#include <stdio.h>
#include <stdlib.h>

int main(){
int A1,A2,B1,B2,S1,S2,B3,A1p,A2p,B1p,B2p,S1p,S2p,OFFRE,OFFRE2,YES;
A1=0;
A2=0;
B1=0;
B2=0;
S1=0;
S2=0;
B3=0;
OFFRE=0;
OFFRE2=0;
YES=0;
A1p=0;
A2p=0;
B1p=0;
B2p=0;
S1p=0;
S2p=0;

/* 1ERES OFFRES */
printf("Pour la 1ère offre écrivez 1 sinon écrivez 0 devant les types d'offres que vous avez obtenues:\n");
printf("A1 : ");
scanf("%d",&A1);
printf("A2 : ");
scanf("%d",&A2);

printf("B1 : ");
scanf("%d",&B1);
printf("B2 : ");
scanf("%d",&B2);

printf("S1 : ");
scanf("%d",&S1);
printf("S2 : ");
scanf("%d",&S2);


if (A1==1){
  printf("Vous avez obtenu une offre d'emploi de classe A1 et vous êtes exclu du processus de placement\n");
  return 0;
}

if (A2==1){
  printf("Vous avez obtenu une offre d'emploi de classe A2\n");
}

if (B1==1){
  printf("Vous avez obtenu un emploi de type B1 et vous ne pourrez pour la 2ième offre qu'avoir une offre d'emploi de type B1\n");
}

if (B2==1){
  printf("Vous avez obtenu un emploi de type B2\n");
}

if (S1==1){
  printf("Vous avez obtenu un stage de classe S1, vous êtes éligibles aux offres d'emploi de classe A1 (donc toutes) et également pouvez avoir un emploi a la suite du stage\n");
}

if (S2==1){
  printf("Vous avez obtenu un stage de classe S2, vous n'êtes éligibles qu'aux offres d'emploi de classe A2\n");
}

/* ACCEPTATION D'UNE 1ERE OFFRE RECUE OU PAS */
if (A2==1 || B1==1 || B2==1 || S1==1 || S2==1){
  printf("\nAcceptez-vous une offre ?\n Tapez 1 pour l'emploi de classe A2,\n Tapez 2 pour l'emploi de type B1,\n Tapez 3 pour l'emploi de type B2,\n Tapez 4 pour l'emploi de stage S1,\n Tapez 5 pour l'emploi de stage S2,\n Tapez 0 pour refuser,\n");
  printf("\nVotre choix : ");
  scanf("\n%d",&OFFRE);
  if (OFFRE==1){
    if (A2==1){
      printf("Vous acceptez l'offre de classe A2 et êtes exclu du processus de placement\n");
      return 0;
    }
    else{
      printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
      return 0;
    }
  }

  if (OFFRE==2){
    if (B1==1){
      printf("Vous acceptez l'offre de type B1 et êtes exclu du processus de placement\n");
      return 0;
    }
    else{
      printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
      return 0;
    }
  }

  if (OFFRE==3){
    if (B2==1){
      printf("Vous acceptez l'offre de type B2 et êtes exclu du processus de placement\n");
      return 0;
    }
    else{
      printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
      return 0;
    }
  }

  if (OFFRE==4){
    if (S1==1){
      printf("Vous acceptez l'offre de stage S1 et êtes exclu du processus de placement\n");
      return 0;
    }
    else{
      printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
      return 0;
    }
  }

  if (OFFRE==5){
    if (S2==1){
      printf("Vous acceptez l'offre de stage S2 et êtes exclu du processus de placement\n");
      return 0;
    }
    else{
      printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
      return 0;
    }
  }

  if (OFFRE==0){
    printf("Vous refusez les 1ères offres mais elles restent disponibles a la fin !\n\n");
  }
  else{
    printf("Choix invalide\n");
    return 0;
  }
}

if (A1==0 && A2==0 && B1==0 && B2==0 && S1==0 && S2==0)
  printf("Vous n'avez pas reçu de première offre.\n\n");

/* 2ND OFFRES 1ère tentative */
printf("Vous n'avez le droit qu'a un maximum de 3 tentatives pour un 2ième emploi.\n");
printf("Pour la 2ème offre écrivez 1 sinon écrivez 0 devant les types d'offres que vous avez obtenues:\n");

printf("A1 : ");
scanf("%d",&A1p);
printf("A2 : ");
scanf("%d",&A2p);

printf("B1 : ");
scanf("%d",&B1p);
printf("B2 : ");
scanf("%d",&B2p);

printf("S1 : ");
scanf("%d",&S1p);
printf("S2 : ");
scanf("%d",&S2p);

if (B1==1){
  if (B1p==1){
    printf("Vous avez obtenu un emploi de type B1 car vous aviez obtenu un emploi de type B1 a la 1ère offre\n");
  }
}

if (S2==1 && A2p==1){
  printf("Vous avez obtenu une offre d'emploi de classe A2 après avoir eu un stage de classe S2\n");
}

if (A1p==1){
  printf("Vous avez obtenu une offre d'emploi de classe A1 et vous êtes exclu du processus de placement\n");
  return 0;
}

if (A2p==1){
  printf("Vous avez obtenu une offre d'emploi de classe A2\n");
}

if (B1p==1){
  printf("Vous avez obtenu un emploi de type B1\n");
}

if (B2p==1){
  printf("Vous avez obtenu un emploi de type B2\n");
}

if (S1p==1){
  printf("Vous avez obtenu un stage de classe S1, vous êtes éligibles aux offres de classe A1 et vous pouvez avoir un emploi a la suite du stage\n");
}

if (S2p==1){
  printf("Vous avez obtenu un stage de classe S2 et n'êtes éligibles qu'aux offres d'emploi de classe A2\n");
}

/* ACCEPTATION D'UNE 2IEME OFFRE RECUE OU PAS */
if (A2p==1 || B1p==1 || B2p==1 || S1p==1 || S2p==1){
  printf("\nAcceptez-vous une 2ième offre ?\n Tapez 1 pour l'emploi de classe A2,\n Tapez 2 pour l'emploi de type B1,\n Tapez 3 pour l'emploi de type B2,\n Tapez 4 pour l'emploi de stage S1,\n Tapez 5 pour l'emploi de stage S2,\n Tapez 0 pour refuser les 2ièmes offres,\n");
  printf("\nVotre choix : ");
  scanf("\n%d",&OFFRE2);
  if (OFFRE2==1){
    if (A2p==1){
      printf("Vous acceptez l'offre de classe A2, la 1ère offre est annulée et vous êtes exclu du processus de placement\n");
      return 0;
    }
    else{
      printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
      return 0;
    }
  }

  if (OFFRE2==2){
    if (B1p==1){
      printf("Vous acceptez l'offre de type B1, la 1ère offre est annulée et vous êtes exclu du processus de placement\n");
      return 0;
    }
    else{
      printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
      return 0;
    }
  }

  if (OFFRE2==3){
    if (B2p==1){
      printf("Vous acceptez l'offre de type B2, la 1ère offre est annulée et vous êtes exclu du processus de placement\n");
      return 0;
    }
    else{
      printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
      return 0;
    }
  }

  if (OFFRE2==4){
    if (S1p==1){
      printf("Vous acceptez l'offre de stage S1, la 1ère offre est annulée et vous êtes exclu du processus de placement\n");
      return 0;
    }
    else{
      printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
      return 0;
    }
  }

  if (OFFRE2==5){
    if (S2p==1){
      printf("Vous acceptez l'offre de stage S2, la 1ère offre est annulée et vous êtes exclu du processus de placement\n");
      return 0;
    }
    else{
      printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
      return 0;
    }
  }

  if (OFFRE2==0){
    printf("Vous refusez les 2iemes offres d'emploi, vous n'avez plus que 2 tentatives\n\n");
  }
  else{
    printf("Choix invalide\n");
    return 0;
  }
}

if (A1p==0 && A2p==0 && B1p==0 && B2p==0 && S1p==0 && S2p==0)
  printf("Vous n'avez pas reçu de seconde offre.\n\n");


  /* 2ND OFFRES 2ieme tentative */
  printf("Vous n'avez plus le droit qu'a un maximum de 2 tentatives pour un 2ième emploi.\n");
  printf("Pour la 2ème offre écrivez 1 sinon écrivez 0 devant les types d'offres que vous avez obtenues:\n");

  printf("A1 : ");
  scanf("%d",&A1p);
  printf("A2 : ");
  scanf("%d",&A2p);

  printf("B1 : ");
  scanf("%d",&B1p);
  printf("B2 : ");
  scanf("%d",&B2p);

  printf("S1 : ");
  scanf("%d",&S1p);
  printf("S2 : ");
  scanf("%d",&S2p);

  if (B1==1){
    if (B1p==1){
      printf("Vous avez obtenu un emploi de type B1 car vous aviez obtenu un emploi de type B1 a la 1ère offre\n");
    }
  }

  if (S2==1 && A2p==1){
    printf("Vous avez obtenu une offre d'emploi de classe A2 après avoir eu un stage de classe S2\n");
  }

  if (A1p==1){
    printf("Vous avez obtenu une offre d'emploi de classe A1 et vous êtes exclu du processus de placement\n");
    return 0;
  }

  if (A2p==1){
    printf("Vous avez obtenu une offre d'emploi de classe A2\n");
  }

  if (B1p==1){
    printf("Vous avez obtenu un emploi de type B1\n");
  }

  if (B2p==1){
    printf("Vous avez obtenu un emploi de type B2\n");
  }

  if (S1p==1){
    printf("Vous avez obtenu un stage de classe S1, vous êtes éligibles aux offres de classe A1 et vous pouvez avoir un emploi a la suite du stage\n");
  }

  if (S2p==1){
    printf("Vous avez obtenu un stage de classe S2 et n'êtes éligibles qu'aux offres d'emploi de classe A2\n");
  }

  /* ACCEPTATION D'UNE 2IEME OFFRE RECUE OU PAS */
  if (A2p==1 || B1p==1 || B2p==1 || S1p==1 || S2p==1){
    printf("\nAcceptez-vous une 2ième offre ?\n Tapez 1 pour l'emploi de classe A2,\n Tapez 2 pour l'emploi de type B1,\n Tapez 3 pour l'emploi de type B2,\n Tapez 4 pour l'emploi de stage S1,\n Tapez 5 pour l'emploi de stage S2,\n Tapez 0 pour refuser les 2ièmes offres,\n");
    printf("\nVotre choix : ");
    scanf("\n%d",&OFFRE2);
    if (OFFRE2==1){
      if (A2p==1){
        printf("Vous acceptez l'offre de classe A2, la 1ère offre est annulée et vous êtes exclu du processus de placement\n");
        return 0;
      }
      else{
        printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
        return 0;
      }
    }

    if (OFFRE2==2){
      if (B1p==1){
        printf("Vous acceptez l'offre de type B1, la 1ère offre est annulée et vous êtes exclu du processus de placement\n");
        return 0;
      }
      else{
        printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
        return 0;
      }
    }

    if (OFFRE2==3){
      if (B2p==1){
        printf("Vous acceptez l'offre de type B2, la 1ère offre est annulée et vous êtes exclu du processus de placement\n");
        return 0;
      }
      else{
        printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
        return 0;
      }
    }

    if (OFFRE2==4){
      if (S1p==1){
        printf("Vous acceptez l'offre de stage S1, la 1ère offre est annulée et vous êtes exclu du processus de placement\n");
        return 0;
      }
      else{
        printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
        return 0;
      }
    }

    if (OFFRE2==5){
      if (S2p==1){
        printf("Vous acceptez l'offre de stage S2, la 1ère offre est annulée et vous êtes exclu du processus de placement\n");
        return 0;
      }
      else{
        printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
        return 0;
      }
    }

    if (OFFRE2==0){
      printf("Vous refusez les 2iemes offres d'emploi, vous n'avez plus qu'1 seule tentative\n\n");
    }
    else{
      printf("Choix invalide\n");
      return 0;
    }
  }

  if (A1p==0 && A2p==0 && B1p==0 && B2p==0 && S1p==0 && S2p==0)
    printf("Vous n'avez pas reçu de seconde offre.\n\n");

    /* 2ND OFFRES 3ème tentative */
    printf("Vous n'avez plus le droit qu'a 1 tentative pour un 2ième emploi.\n");
    printf("Pour la 2ème offre écrivez 1 sinon écrivez 0 devant les types d'offres que vous avez obtenues:\n");

    printf("A1 : ");
    scanf("%d",&A1p);
    printf("A2 : ");
    scanf("%d",&A2p);

    printf("B1 : ");
    scanf("%d",&B1p);
    printf("B2 : ");
    scanf("%d",&B2p);

    printf("S1 : ");
    scanf("%d",&S1p);
    printf("S2 : ");
    scanf("%d",&S2p);

    if (B1==1){
      if (B1p==1){
        printf("Vous avez obtenu un emploi de type B1 car vous aviez obtenu un emploi de type B1 a la 1ère offre\n");
      }
    }

    if (S2==1 && A2p==1){
      printf("Vous avez obtenu une offre d'emploi de classe A2 après avoir eu un stage de classe S2\n");
    }

    if (A1p==1){
      printf("Vous avez obtenu une offre d'emploi de classe A1 et vous êtes exclu du processus de placement\n");
      return 0;
    }

    if (A2p==1){
      printf("Vous avez obtenu une offre d'emploi de classe A2\n");
    }

    if (B1p==1){
      printf("Vous avez obtenu un emploi de type B1\n");
    }

    if (B2p==1){
      printf("Vous avez obtenu un emploi de type B2\n");
    }

    if (S1p==1){
      printf("Vous avez obtenu un stage de classe S1, vous êtes éligibles aux offres de classe A1 et vous pouvez avoir un emploi a la suite du stage\n");
    }

    if (S2p==1){
      printf("Vous avez obtenu un stage de classe S2 et n'êtes éligibles qu'aux offres d'emploi de classe A2\n");
    }

    /* ACCEPTATION D'UNE 2IEME OFFRE RECUE OU PAS */
    if (A2p==1 || B1p==1 || B2p==1 || S1p==1 || S2p==1){
      printf("\nAcceptez-vous une 2ième offre ?\n Tapez 1 pour l'emploi de classe A2,\n Tapez 2 pour l'emploi de type B1,\n Tapez 3 pour l'emploi de type B2,\n Tapez 4 pour l'emploi de stage S1,\n Tapez 5 pour l'emploi de stage S2,\n Tapez 0 pour refuser les 2ièmes offres,\n");
      printf("\nVotre choix : ");
      scanf("\n%d",&OFFRE2);
      if (OFFRE2==1){
        if (A2p==1){
          printf("Vous acceptez l'offre de classe A2, la 1ère offre est annulée et vous êtes exclu du processus de placement\n");
          return 0;
        }
        else{
          printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
          return 0;
        }
      }

      if (OFFRE2==2){
        if (B1p==1){
          printf("Vous acceptez l'offre de type B1, la 1ère offre est annulée et vous êtes exclu du processus de placement\n");
          return 0;
        }
        else{
          printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
          return 0;
        }
      }

      if (OFFRE2==3){
        if (B2p==1){
          printf("Vous acceptez l'offre de type B2, la 1ère offre est annulée et vous êtes exclu du processus de placement\n");
          return 0;
        }
        else{
          printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
          return 0;
        }
      }

      if (OFFRE2==4){
        if (S1p==1){
          printf("Vous acceptez l'offre de stage S1, la 1ère offre est annulée et vous êtes exclu du processus de placement\n");
          return 0;
        }
        else{
          printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
          return 0;
        }
      }

      if (OFFRE2==5){
        if (S2p==1){
          printf("Vous acceptez l'offre de stage S2, la 1ère offre est annulée et vous êtes exclu du processus de placement\n");
          return 0;
        }
        else{
          printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
          return 0;
        }
      }

      if (OFFRE2==0){
        printf("Vous refusez les 2iemes offres d'emploi, vous n'avez plus de tentatives\n\n");
      }
      else{
        printf("Choix invalide\n");
        return 0;
      }
    }

    if (A1p==0 && A2p==0 && B1p==0 && B2p==0 && S1p==0 && S2p==0)
      printf("Vous n'avez pas reçu de seconde offre.\n\n");


printf("Voulez vous acceptez l'une des 1ères offres d'emploi ?\n");
/* ACCEPTATION D'UNE 1ERE OFFRE RECUE OU PAS */
if (A2==1 || B1==1 || B2==1 || S1==1 || S2==1){
  printf("\nAcceptez-vous une offre ?\n Tapez 1 pour l'emploi de classe A2,\n Tapez 2 pour l'emploi de type B1,\n Tapez 3 pour l'emploi de type B2,\n Tapez 4 pour l'emploi de stage S1,\n Tapez 5 pour l'emploi de stage S2,\n Tapez 0 pour refuser,\n");
  printf("\nVotre choix : ");
  scanf("\n%d",&OFFRE);
  if (OFFRE==1){
    if (A2==1){
      printf("Vous acceptez l'offre de classe A2 et êtes exclu du processus de placement\n");
      return 0;
    }
    else{
      printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
      return 0;
    }
  }

  if (OFFRE==2){
    if (B1==1){
      printf("Vous acceptez l'offre de type B1 et êtes exclu du processus de placement\n");
      return 0;
    }
    else{
      printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
      return 0;
    }
  }

  if (OFFRE==3){
    if (B2==1){
      printf("Vous acceptez l'offre de type B2 et êtes exclu du processus de placement\n");
      return 0;
    }
    else{
      printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
      return 0;
    }
  }

  if (OFFRE==4){
    if (S1==1){
      printf("Vous acceptez l'offre de stage S1 et êtes exclu du processus de placement\n");
      return 0;
    }
    else{
      printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
      return 0;
    }
  }

  if (OFFRE==5){
    if (S2==1){
      printf("Vous acceptez l'offre de stage S2 et êtes exclu du processus de placement\n");
      return 0;
    }
    else{
      printf("Vous ne pouvez pas acceptez une offre que vous n'avez pas reçu\n");
      return 0;
    }
  }

  if (OFFRE==0){
    printf("Vous refusez les offres d'emploi et êtes exclus du processus de placement.\n\n");
  }
  else{
    printf("Choix invalide\n");
    return 0;
  }
}

return 0;
}
