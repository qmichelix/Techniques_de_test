#include <stdio.h>
#include <stdlib.h>

int main(){
float x,y,z;
printf("Donner x, y et z les longueurs de 3 côtés d’un triangle :\n");
printf("x : ");
scanf("%f",&x);
printf("y : ");
scanf("%f",&y);
printf("z : ");
scanf("%f",&z);
printf("x : %f, y : %f, z : %f\n", x,y,z);

//cas non-triangle
if ((x >= y and x >= z and y + z < x) or (y >= x and y >= z and x + z < y) or (z >= x and z >= y and x + y < z)) {
  printf("\nL’objet n’est pas un triangle\n") ;

/* cas impossible si (x ou y ou z < 0) OU si (x ou y ou z est vide) OU si (x ou y ou z est un caractère autre qu'un nombre)*/
  printf("\nou est un Cas impossible en raison des données d'entrées\n");
}

//cas scalène
if ((x > y and x > z and y + z >= x and y != z and y != x and x != z) or (y > x and y > z and x + z >= y and x != z and x != y and y != z) or (z > x and z > y and x + y >= z and x != y and x != z and z != y))
  printf("\nL'objet est un triangle scalène\n");

//cas isocèle
if ((x >= y and x >= z and y + z >= x and y == z and y != x and z != x) or (y >= x and y >= z and x + z >= y and x == z and x != y and z != y) or (z >= x and z >= y and x + y >= z and x == y and x != z and y != z))
  printf("\nL'objet est un triangle isocèle\n");

//cas équilatéral
if ((x >= y and x >= z and y + z >= x and x == z and x == y))
  printf("\nL'objet est un triangle équilatéral\n");

return 0;
}
