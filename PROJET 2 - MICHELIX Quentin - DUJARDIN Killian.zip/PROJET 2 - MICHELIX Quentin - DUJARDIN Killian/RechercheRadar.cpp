#include <iostream>
#include <math.h>
#include <string>

#define N0 2
#define N1 1
#define N2 0
using namespace std;

int main(){
  string Donnee;
  int count0=0, count1=0, count2=0;

  do{
      cout<<"----- DEBUT DE LA SEQUENCE -----"<<endl;
      cout<<"Entrez une fréquence F00 OU F01 : ";
      cin>>Donnee;
    }while((Donnee != "F00") && (Donnee != "F01"));

  cout<<"\n----- SOUS-SUITE SIGMA -----";
  cout<<"\nEntrez une fréquence F10 OU F11 OU F12";
  cout<<"\nOu entrez une fréquence F20 OU F21 pour terminer la séquence";

  do{
      cout<<"\nEntrez une fréquence : ";
      cin>>Donnee;
      if(Donnee=="F10"){
          count0++;
      }
      if(Donnee=="F11"){
          count1++;
      }
      if(Donnee=="F12"){
          count2++;
      }
  } while ((Donnee != "F20") && (Donnee != "F21"));

  cout<<"\n----- FIN DE LA SEQUENCE -----\n"<<endl;
  if((count0<N0) || (count1<N1) || (count2<N2)){
      cout<<"-/!\\- ATTENTION -/!\\-\nLa signature ne correspond à aucun type de missile"<<endl;
  }
  else if (log(count0) >= log(count1 + 4*count2)){
          cout<<"\n-- Missile de type A détecté --"<<endl;
      }
      else if (log(count1) >= log(2*count2)){
              cout<<"\n-- Missile de type B détecté --"<<endl;
          }
          else{
              cout<<"\n-- Missile de type C détecté --"<<endl;
          }
  return 0;
}
