#include <iostream>
#include "unistd.h"
using namespace std;

void look (int cle, int *tab, int taille, bool trouve, int A){
  int droit = taille, gauche = 0;

  while (gauche <= droit && trouve == false){
    A = (droit + gauche)/2;
    tab[A] == cle ? trouve = true : (tab[A] > cle ? gauche = A + 1 : droit = A + 1);
  }
  if (trouve == true)
    cout << "Element trouvé à l'indice : " << A  << endl;
  else
    cout << "Element non trouvé" << endl;
}

//Ici il n'y a pas le int main() donc l'execution ne pourra pas marcher
